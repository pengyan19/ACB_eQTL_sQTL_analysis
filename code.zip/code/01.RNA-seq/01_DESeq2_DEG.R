# ============================================================
# 01_DESeq2_DEG.R
# 差异表达分析主流程
# ------------------------------------------------------------
# 输入:
#   - 00.gene.count.txt   featureCounts 输出的 counts 矩阵
#                         (前6列注释 + 第7列起为样本counts)
# 输出:
#   - Counts.filtered.csv 过滤后的 counts 矩阵
#   - SampleInfo.csv      样本分组信息
#   - DESeq2_Object.RData DESeq2 对象 + VST 变换结果
#   - DEG_XX_vs_YY.csv    各比较组全基因差异结果
#   - DEG_XX_vs_YY_sig.csv 显著差异基因 (padj<0.05 & |log2FC|>2)
#   - DEG_summary.csv     各比较组 Up/Down/Total 数量
# 用法: 在项目根目录运行 Rscript 01_DESeq2_DEG.R
# ============================================================

rm(list = ls())
options(stringsAsFactors = FALSE)

library(DESeq2)

# ---------- 1. 读取 featureCounts 输出 ----------
counts <- read.table(
  "00.gene.count.txt",
  header = TRUE, sep = "\t",
  check.names = FALSE, quote = "", row.names = 1
)
# 去掉前5列注释 (Chr, Start, End, Strand, Length)
counts <- counts[, -(1:5)]

# ---------- 2. 样本过滤 ----------
# 删除 3 龄期样本（列名以 "3" 开头）
counts <- counts[, !grepl("^3", colnames(counts))]
# 仅保留四个目标组
keep <- grepl("^(HNH|HDH|SNH|SDH)", colnames(counts))
counts <- counts[, keep]

cat("Genes:", nrow(counts), "| Samples:", ncol(counts), "\n")
print(table(sub("-.*", "", colnames(counts))))

# 样本分组信息
sample_info <- data.frame(
  Sample = colnames(counts),
  Group  = sub("-.*", "", colnames(counts))
)
rownames(sample_info) <- sample_info$Sample

write.csv(counts, "Counts.filtered.csv", quote = FALSE)
write.csv(sample_info, "SampleInfo.csv", quote = FALSE, row.names = FALSE)

# ---------- 3. DESeq2 差异分析 ----------
counts <- as.matrix(counts); storage.mode(counts) <- "integer"

sample_info <- read.csv("SampleInfo.csv", stringsAsFactors = FALSE)
rownames(sample_info) <- sample_info$Sample
sample_info <- sample_info[colnames(counts), ]

dds <- DESeqDataSetFromMatrix(
  countData = counts,
  colData   = sample_info,
  design    = ~ Group
)
# 低表达过滤: 至少在3个样本中 counts>=10
keep <- rowSums(counts(dds) >= 10) >= 3
dds <- dds[keep, ]

dds$Group <- factor(dds$Group, levels = c("HNH", "HDH", "SNH", "SDH"))

# 核心差异分析（正式运行时取消注释下一行）
# dds <- DESeq(dds)

# 标准化 counts 与 VST 变换（用于 PCA / 聚类 / 热图）
norm_counts <- counts(dds, normalized = TRUE)
vsd <- vst(dds, blind = FALSE)
save(dds, vsd, file = "DESeq2_Object.RData")

# ---------- 4. 提取各比较组差异结果 ----------
compare <- function(dds, a, b) {
  res <- as.data.frame(results(dds, contrast = c("Group", a, b)))
  res$Gene <- rownames(res)
  res <- res[, c("Gene", "baseMean", "log2FoldChange",
                 "lfcSE", "stat", "pvalue", "padj")]
  res[order(res$padj), ]
}

comparisons <- c("HNH_HDH", "SNH_SDH", "HNH_SNH", "HDH_SDH")
pairs <- list(
  HNH_HDH = c("HNH", "HDH"),
  SNH_SDH = c("SNH", "SDH"),
  HNH_SNH = c("HNH", "SNH"),
  HDH_SDH = c("HDH", "SDH")
)

res_list <- lapply(comparisons, function(nm) compare(dds, pairs[[nm]][1], pairs[[nm]][2]))
names(res_list) <- comparisons

for (nm in comparisons) {
  write.csv(res_list[[nm]], paste0("DEG_", nm, ".csv"), row.names = FALSE)
}

# ---------- 5. 筛选显著 DEG 并统计数量 ----------
filter_deg <- function(res, padj_cutoff = 0.05, log2fc_cutoff = 2) {
  subset(res, !is.na(padj) & padj < padj_cutoff & abs(log2FoldChange) > log2fc_cutoff)
}
count_deg <- function(res, padj_cutoff = 0.05, log2fc_cutoff = 2) {
  up   <- sum(!is.na(res$padj) & res$padj < padj_cutoff & res$log2FoldChange >  log2fc_cutoff)
  down <- sum(!is.na(res$padj) & res$padj < padj_cutoff & res$log2FoldChange < -log2fc_cutoff)
  data.frame(Up = up, Down = down, Total = up + down)
}

summary_table <- data.frame(row.names = comparisons)
for (nm in comparisons) {
  deg <- filter_deg(res_list[[nm]])
  write.csv(deg, paste0("DEG_", nm, "_sig.csv"), row.names = FALSE)
  summary_table[nm, ] <- count_deg(res_list[[nm]])
}
write.csv(summary_table, "DEG_summary.csv")

cat("\nDEG summary (padj<0.05, |log2FC|>2):\n")
print(summary_table)
