# ============================================================
# 02_Visualization.R
# 差异分析可视化
# ------------------------------------------------------------
# 输入:
#   - DESeq2_Object.RData  DESeq2 对象 (来自 01_DESeq2_DEG.R)
#   - DEG_XX_vs_YY.csv     各比较组全基因差异结果
#   - DEG_summary.csv      显著 DEG 数量统计
# 输出:
#   - PCA.pdf              PCA 聚类图
#   - Volcano_XX_vs_YY.pdf/png  四组火山图
#   - DEG_Barplot.pdf/png  显著 DEG 数量柱状图
# 用法: Rscript 02_Visualization.R
# ============================================================

rm(list = ls())
library(DESeq2)
library(ggplot2)

mycolor <- c(HNH = "#1B9E77", HDH = "#D95F02", SNH = "#7570B3", SDH = "#E7298A")

# ---------- 1. PCA ----------
load("DESeq2_Object.RData")
pcaData <- plotPCA(vsd, intgroup = "Group", returnData = TRUE)
percentVar <- round(100 * attr(pcaData, "percentVar"), 1)

p_pca <- ggplot(pcaData, aes(PC1, PC2, color = Group, fill = Group)) +
  stat_ellipse(geom = "polygon", alpha = 0.15, color = NA) +
  geom_point(size = 3.5) +
  scale_color_manual(values = mycolor) + scale_fill_manual(values = mycolor) +
  labs(x = paste0("PC1 (", percentVar[1], "%)"), y = paste0("PC2 (", percentVar[2], "%)")) +
  theme_classic(base_size = 14) +
  theme(legend.title = element_blank(), legend.position = "right",
        axis.text = element_text(color = "black"), axis.title = element_text(face = "bold"))
ggsave("PCA.pdf", p_pca, width = 6, height = 5)

# ---------- 2. 火山图 ----------
comparisons <- c("HNH_HDH", "SNH_SDH", "HNH_SNH", "HDH_SDH")
titles <- c(HNH_HDH = "HNH vs HDH", SNH_SDH = "SNH vs SDH",
            HNH_SNH = "HNH vs SNH", HDH_SDH = "HDH vs SDH")

vol_color <- c(Up = "#D95F02", Down = "#1B9E77", NS = "grey80")

plot_volcano <- function(res, title, padj_cutoff = 0.05, log2fc_cutoff = 2) {
  res$Group <- "NS"
  res$Group[res$padj < padj_cutoff & res$log2FoldChange >  log2fc_cutoff] <- "Up"
  res$Group[res$padj < padj_cutoff & res$log2FoldChange < -log2fc_cutoff] <- "Down"
  res$Group[is.na(res$padj)] <- "NS"
  res$Group <- factor(res$Group, levels = c("Up", "Down", "NS"))
  res$minusLog10P <- -log10(res$padj)
  res$minusLog10P[is.infinite(res$minusLog10P)] <-
    max(res$minusLog10P[is.finite(res$minusLog10P)], na.rm = TRUE)

  ggplot(res, aes(log2FoldChange, minusLog10P, color = Group)) +
    geom_point(alpha = 0.7, size = 1.2) +
    scale_color_manual(values = vol_color) +
    geom_vline(xintercept = c(-log2fc_cutoff, log2fc_cutoff), linetype = 2, color = "grey50") +
    geom_hline(yintercept = -log10(padj_cutoff), linetype = 2, color = "grey50") +
    labs(title = title, x = "log2 Fold Change", y = "-log10(adjusted P value)") +
    theme_classic(base_size = 14) +
    theme(legend.title = element_blank(), plot.title = element_text(hjust = 0.5, face = "bold"))
}

for (nm in comparisons) {
  res <- read.csv(paste0("DEG_", nm, ".csv"))
  p <- plot_volcano(res, titles[nm])
  ggsave(paste0("Volcano_", nm, ".pdf"), p, width = 6, height = 5)
  ggsave(paste0("Volcano_", nm, ".png"), p, width = 6, height = 5, dpi = 600)
}

# ---------- 3. DEG 数量柱状图 ----------
deg_summary <- read.csv("DEG_summary.csv", row.names = 1, check.names = FALSE)
deg_summary$Comparison <- rownames(deg_summary)

deg_long <- reshape2::melt(
  deg_summary, id.vars = "Comparison",
  measure.vars = c("Total", "Up", "Down"),
  variable.name = "Type", value.name = "Count"
)
# 按用户指定顺序排列
deg_long$Comparison <- factor(deg_long$Comparison,
  levels = c("HNH_SNH", "HDH_SDH", "HNH_HDH", "SNH_SDH"))
deg_long$Type <- factor(deg_long$Type, levels = c("Total", "Up", "Down"))

p_bar <- ggplot(deg_long, aes(Comparison, Count, fill = Type)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.7,
           color = "black", linewidth = 0.3) +
  geom_text(aes(label = Count), position = position_dodge(width = 0.8),
            vjust = -0.3, size = 3.5) +
  scale_fill_manual(values = c(Total = "#B0B0B0", Up = "#E64B35", Down = "#4DBBD5"),
                    labels = c("Total DEGs", "Up-regulated", "Down-regulated")) +
  labs(x = "Comparison", y = "Number of DEGs", fill = "") +
  theme_bw() +
  theme(panel.grid.major.x = element_blank(), panel.grid.minor = element_blank(),
        axis.text.x = element_text(size = 10), axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12), axis.title.y = element_text(size = 12),
        legend.position = "top", legend.text = element_text(size = 10),
        plot.title = element_text(hjust = 0.5, size = 14, face = "bold")) +
  ggtitle("Number of Differentially Expressed Genes")

ggsave("DEG_Barplot.pdf", p_bar, width = 8, height = 6, useDingbats = FALSE)
ggsave("DEG_Barplot.png", p_bar, width = 8, height = 6, dpi = 300)

cat("Done! Output: PCA.pdf, Volcano_*.pdf/png, DEG_Barplot.pdf/png\n")
