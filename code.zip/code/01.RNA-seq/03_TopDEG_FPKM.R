# ============================================================
# 03_TopDEG_FPKM.R
# Top DEG 汇总与 FPKM 计算
# ------------------------------------------------------------
# 输入:
#   - DEG_XX_vs_YY_sig.csv  显著差异基因 (来自 01_DESeq2_DEG.R)
#   - Counts.filtered.csv   过滤后 counts 矩阵
#   - 00.gene.count.txt     featureCounts 原始输出
# 输出:
#   - Top10_XX_vs_YY_Up/Down.csv   各比较组 Top10 差异基因
#   - TopDEGs_unique.csv / TopDEGs_gene_list.txt   去重基因列表
#   - FPKM.csv / FPKM.log2.csv     表达量矩阵 (画热图用)
# 用法: Rscript 03_TopDEG_FPKM.R
# ============================================================

rm(list = ls())

# ---------- 1. 提取各比较组 Top10 Up/Down 基因 ----------
top_gene_summary <- function(sig_file, counts_file, top_n = 10,
                             padj_cutoff = 0.05, log2fc_cutoff = 2) {
  res <- read.csv(sig_file, check.names = FALSE)
  counts <- read.csv(counts_file, check.names = FALSE)
  colnames(counts)[1] <- "Gene"
  expr <- counts[, -1]
  counts_summary <- data.frame(
    Gene = counts$Gene,
    NonZero = rowSums(expr > 0),
    Max = apply(expr, 1, max),
    Mean = rowMeans(expr)
  )
  pick_top <- function(direction) {
    if (direction == "Up") idx <- res$padj < padj_cutoff & res$log2FoldChange >  log2fc_cutoff
    else                   idx <- res$padj < padj_cutoff & res$log2FoldChange < -log2fc_cutoff
    sub <- res[!is.na(res$padj) & idx, ]
    sub <- sub[order(sub$padj), ]
    merge(head(sub, top_n), counts_summary, by = "Gene", all.x = TRUE)
  }
  list(Up = pick_top("Up"), Down = pick_top("Down"))
}

comparisons <- c("HNH_HDH", "SNH_SDH", "HNH_SNH", "HDH_SDH")
for (nm in comparisons) {
  top <- top_gene_summary(paste0("DEG_", nm, "_sig.csv"), "Counts.filtered.csv")
  write.csv(top$Up,   paste0("Top10_", nm, "_Up.csv"),   row.names = FALSE)
  write.csv(top$Down, paste0("Top10_", nm, "_Down.csv"), row.names = FALSE)
}

# ---------- 2. 整合去重 ----------
all_genes <- data.frame()
for (nm in comparisons) {
  for (dir in c("Up", "Down")) {
    f <- paste0("Top10_", nm, "_", dir, ".csv")
    if (file.exists(f)) {
      df <- read.csv(f)
      all_genes <- rbind(all_genes, data.frame(
        Gene = df$Gene, Comparison = nm, Direction = dir,
        log2FoldChange = df$log2FoldChange, padj = df$padj
      ))
    }
  }
}
gene_count_df <- as.data.frame(table(all_genes$Gene))
names(gene_count_df) <- c("Gene", "Occurrences")
gene_count_df <- gene_count_df[order(-gene_count_df$Occurrences, gene_count_df$Gene), ]

write.csv(gene_count_df, "TopDEGs_unique.csv", row.names = FALSE)
write.table(data.frame(Gene = gene_count_df$Gene), "TopDEGs_gene_list.txt",
            row.names = FALSE, col.names = FALSE, quote = FALSE)

# ---------- 3. 计算 FPKM ----------
raw <- read.table("00.gene.count.txt", header = TRUE, sep = "\t",
                  check.names = FALSE, quote = "")
rownames(raw) <- raw$Geneid
gene_length <- raw$Length
count_matrix <- as.matrix(raw[, 7:ncol(raw)]); storage.mode(count_matrix) <- "numeric"

library_size <- colSums(count_matrix)
fpkm <- count_matrix
for (i in 1:ncol(fpkm)) {
  fpkm[, i] <- (count_matrix[, i] / (gene_length / 1000)) / (library_size[i] / 1e6)
}
fpkm_out <- as.data.frame(fpkm); fpkm_out$Gene <- rownames(fpkm_out)
fpkm_out <- fpkm_out[, c("Gene", colnames(fpkm))]
write.csv(fpkm_out, "FPKM.csv", row.names = FALSE, quote = FALSE)

fpkm_log2 <- log2(fpkm + 1)
fpkm_log2_out <- as.data.frame(fpkm_log2); fpkm_log2_out$Gene <- rownames(fpkm_log2_out)
fpkm_log2_out <- fpkm_log2_out[, c("Gene", colnames(fpkm))]
write.csv(fpkm_log2_out, "FPKM.log2.csv", row.names = FALSE, quote = FALSE)

cat("\nDone!\n")
cat("Unique DEGs:", nrow(gene_count_df), "\n")
cat("Output: Top10_*.csv, TopDEGs_*.csv/txt, FPKM.csv, FPKM.log2.csv\n")
