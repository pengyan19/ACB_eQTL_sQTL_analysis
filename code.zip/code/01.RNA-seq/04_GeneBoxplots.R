# ============================================================
# 04_GeneBoxplots.R
# 候选基因表达箱线图（featurecounts FPKM 来源）
# ------------------------------------------------------------
# 输入:
#   - FPKM.log2.csv    log2(FPKM+1) 表达矩阵
#                     (第1列 Gene, 其余列为样本)
#   - gene.txt         候选基因ID列表(一行一个)
# 输出:
#   - gene_boxplots_final.png/.pdf  所有基因箱线图拼图
#   - gene_significance_rank.txt    基因显著性(ANOVA p)排序
# 用法:
#   Rscript 04_GeneBoxplots.R <FPKM_log2.csv> <gene.txt> <输出前缀>
# 示例:
#   Rscript 04_GeneBoxplots.R FPKM.log2.csv gene.txt gene_boxplots
# 说明:
#   - 分组规则: 样本名取前2个字母 (HN/HD/SN/SD)
#   - 比较组: HN-HD, HN-SN, HD-SD, SN-SD (t.test 标注 p 值)
#   - 按 ANOVA p 值从显著到不显著排序
#   - 拼图 8x6=48 位, 超过48基因自动分页
# ============================================================
rm(list = ls())

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 3) {
  stop("用法: Rscript 04_GeneBoxplots.R <FPKM_log2.csv> <gene.txt> <输出前缀>")
}
fpkm_file <- args[1]
gene_file <- args[2]
out_prefix <- args[3]

# =========================
# 1. 读取基因列表与 FPKM
# =========================
gene_list <- read.table(gene_file, header = FALSE, stringsAsFactors = FALSE)$V1
cat("共读取", length(gene_list), "个基因\n")

data <- read.csv(fpkm_file, header = TRUE, check.names = FALSE)
cat("数据共", nrow(data), "个基因，", ncol(data) - 1, "个样本\n")

# 筛选目标基因
data <- data[data$Gene %in% gene_list, ]
cat("筛选后剩余", nrow(data), "个基因\n")

library(ggplot2)
library(dplyr)
library(tidyr)
library(patchwork)

# 宽表转长表
data_long <- pivot_longer(data, cols = -Gene, names_to = "Sample", values_to = "FPKM")

# 分组: 只取前2个字母 (忽略第三字母 H/T)
data_long$Group <- substr(data_long$Sample, 1, 2)
data_long$Group <- factor(data_long$Group, levels = c("HN", "HD", "SN", "SD"))
data_long <- data_long %>% rename(gene = Gene)

# =========================
# 颜色 (Normal=米黄, Stress=蓝)
# =========================
tissue_cols <- c(
  "HN" = "#E8E4A8",  # 南方正常 - 米黄
  "HD" = "#4DBBD5",  # 南方滞育 - 蓝
  "SN" = "#E8E4A8",  # 北方正常 - 米黄
  "SD" = "#4DBBD5"   # 北方滞育 - 蓝
)

# =========================
# 2. 计算基因显著性 (ANOVA)
# =========================
gene_stats <- data_long %>%
  group_by(gene) %>%
  summarise(
    anova_p = summary(aov(FPKM ~ Group))[[1]][["Pr(>F)"]][1],
    mean_HN = mean(FPKM[Group == "HN"]),
    mean_HD = mean(FPKM[Group == "HD"]),
    mean_SN = mean(FPKM[Group == "SN"]),
    mean_SD = mean(FPKM[Group == "SD"])
  )

# NA/NaN 防护
gene_stats <- gene_stats %>%
  mutate(anova_p = ifelse(is.na(anova_p) | is.nan(anova_p), 1, anova_p)) %>%
  arrange(anova_p)
cat("按差异显著性排序完成\n")

write.table(gene_stats, paste0(out_prefix, "_rank.txt"),
            sep = "\t", quote = FALSE, row.names = FALSE)
cat("显著性排名已保存到", paste0(out_prefix, "_rank.txt"), "\n")

ordered_genes <- gene_stats$gene
n_genes <- length(ordered_genes)
cat("共", n_genes, "个基因用于绘图\n")

# =========================
# 3. 单个基因绘图函数
# =========================
plot_single_gene <- function(gene_name, gene_data) {
  group_means <- gene_data %>%
    group_by(Group) %>%
    summarise(Mean = round(mean(FPKM), 2))

  comps <- list(
    c("HN", "HD"),  # 南方正常 vs 南方滞育
    c("HN", "SN"),  # 南方正常 vs 北方正常
    c("HD", "SD"),  # 南方滞育 vs 北方滞育
    c("SN", "SD")   # 北方正常 vs 北方滞育
  )

  p_vals <- sapply(comps, function(comp) {
    g1 <- gene_data$FPKM[gene_data$Group == comp[1]]
    g2 <- gene_data$FPKM[gene_data$Group == comp[2]]
    tt <- tryCatch(t.test(g1, g2)$p.value, error = function(e) NA_real_)
    if (length(tt) == 0 || is.null(tt)) return(NA_real_)
    return(tt)
  })

  format_p <- function(p) {
    if (is.na(p) || is.nan(p) || length(p) == 0) return("p=NA")
    if (p < 0.001) sprintf("p=%.1e", p)
    else if (p < 0.01) sprintf("p=%.3f", p)
    else sprintf("p=%.2f", p)
  }
  p_labels <- sapply(p_vals, format_p)

  # y轴范围 (基于箱线图须线, 不受异常值干扰)
  box_stats <- gene_data %>%
    group_by(Group) %>%
    summarise(
      q1 = quantile(FPKM, 0.25), q3 = quantile(FPKM, 0.75),
      iqr = IQR(FPKM), max_val = max(FPKM), min_val = min(FPKM)
    )
  box_stats$whisker_top <- pmin(box_stats$q3 + 1.5 * box_stats$iqr, box_stats$max_val)
  max_whisker <- max(box_stats$whisker_top)

  p_space <- max_whisker * 0.15
  label_y <- c(
    max_whisker + p_space * 1,
    max_whisker + p_space * 2.2,
    max_whisker + p_space * 3.4,
    max_whisker + p_space * 4.6
  )
  y_limit <- max(label_y) + p_space * 0.5
  y_bottom <- -max_whisker * 0.15

  p <- ggplot(gene_data, aes(x = Group, y = FPKM, fill = Group)) +
    geom_boxplot(width = 0.6, alpha = 0.8, outlier.shape = NA, linewidth = 0.4) +
    scale_fill_manual(values = tissue_cols, breaks = c("HN", "HD"),
                      labels = c("Normal", "Stress"), name = "") +
    stat_boxplot(geom = "errorbar", width = 0.15, linewidth = 0.4) +

    # p值线段和标注
    annotate("segment", x = 1, xend = 2, y = label_y[1], yend = label_y[1], linewidth = 0.3) +
    annotate("segment", x = 1, xend = 1, y = label_y[1], yend = label_y[1] - p_space*0.2, linewidth = 0.3) +
    annotate("segment", x = 2, xend = 2, y = label_y[1], yend = label_y[1] - p_space*0.2, linewidth = 0.3) +
    annotate("text", x = 1.5, y = label_y[1] + p_space*0.15, label = p_labels[1], size = 2.5, vjust = 0) +

    annotate("segment", x = 1, xend = 3, y = label_y[2], yend = label_y[2], linewidth = 0.3) +
    annotate("segment", x = 1, xend = 1, y = label_y[2], yend = label_y[2] - p_space*0.2, linewidth = 0.3) +
    annotate("segment", x = 3, xend = 3, y = label_y[2], yend = label_y[2] - p_space*0.2, linewidth = 0.3) +
    annotate("text", x = 2, y = label_y[2] + p_space*0.15, label = p_labels[2], size = 2.5, vjust = 0) +

    annotate("segment", x = 2, xend = 4, y = label_y[3], yend = label_y[3], linewidth = 0.3) +
    annotate("segment", x = 2, xend = 2, y = label_y[3], yend = label_y[3] - p_space*0.2, linewidth = 0.3) +
    annotate("segment", x = 4, xend = 4, y = label_y[3], yend = label_y[3] - p_space*0.2, linewidth = 0.3) +
    annotate("text", x = 3, y = label_y[3] + p_space*0.15, label = p_labels[3], size = 2.5, vjust = 0) +

    annotate("segment", x = 3, xend = 4, y = label_y[4], yend = label_y[4], linewidth = 0.3) +
    annotate("segment", x = 3, xend = 3, y = label_y[4], yend = label_y[4] - p_space*0.2, linewidth = 0.3) +
    annotate("segment", x = 4, xend = 4, y = label_y[4], yend = label_y[4] - p_space*0.2, linewidth = 0.3) +
    annotate("text", x = 3.5, y = label_y[4] + p_space*0.15, label = p_labels[4], size = 2.5, vjust = 0) +

    # 平均值标注
    annotate("text", x = 1:4, y = y_bottom + abs(y_bottom) * 0.5,
             label = paste0("Avg=", group_means$Mean), size = 2.2, vjust = 1) +

    coord_cartesian(ylim = c(y_bottom, y_limit)) +
    ggtitle(gene_name) +
    labs(x = "", y = "") +
    theme_classic(base_size = 8) +
    theme(
      plot.title = element_text(size = 6.5, hjust = 0.5, face = "bold"),
      legend.position = c(0.25, 0.95),
      legend.title = element_blank(),
      legend.text = element_text(size = 6),
      legend.background = element_blank(),
      legend.key = element_blank(),
      legend.key.size = unit(0.4, "cm"),
      legend.margin = margin(0, 0, 0, 0),
      axis.text.x = element_text(size = 6.5),
      axis.text.y = element_text(size = 6.5),
      axis.line = element_line(linewidth = 0.3),
      axis.ticks = element_line(linewidth = 0.3),
      plot.margin = margin(2, 2, 2, 2)
    )
  return(p)
}

# =========================
# 4. 生成所有基因的图
# =========================
cat("正在生成", n_genes, "个基因的箱线图...\n")
plot_list <- list()
for (i in 1:n_genes) {
  gene_name <- ordered_genes[i]
  gene_data <- data_long %>% filter(gene == gene_name)
  plot_list[[i]] <- plot_single_gene(gene_name, gene_data)
  if (i %% 10 == 0) cat("  已完成", i, "/", n_genes, "\n")
}
cat("全部完成！\n")

# =========================
# 5. 拼图并保存 (8列, 每行8个, 自动分页)
# =========================
ncol <- 8
nrow <- 6
per_page <- ncol * nrow
n_pages <- ceiling(n_genes / per_page)
cat("拼接中：", ncol, "列 x", nrow, "行 =", per_page, "个位置/页, 共", n_pages, "页\n")

for (pg in 1:n_pages) {
  idx_start <- (pg - 1) * per_page + 1
  idx_end <- min(pg * per_page, n_genes)
  page_plots <- plot_list[idx_start:idx_end]
  # 补足到整页
  if (length(page_plots) < per_page) {
    for (k in 1:(per_page - length(page_plots))) {
      page_plots[[length(page_plots) + 1]] <- plot_spacer()
    }
  }
  combined <- wrap_plots(page_plots, ncol = ncol, nrow = nrow)
  suffix <- if (n_pages > 1) paste0("_p", pg) else ""
  ggsave(paste0(out_prefix, suffix, ".pdf"), combined, width = 28, height = 21)
  ggsave(paste0(out_prefix, suffix, ".png"), combined, width = 28, height = 21, dpi = 300)
  cat("已保存：", paste0(out_prefix, suffix, ".pdf / .png"), "\n")
}

cat("输出文件：\n")
cat("  -", paste0(out_prefix, "*.png/.pdf"), "(箱线图拼图)\n")
cat("  -", paste0(out_prefix, "_rank.txt"), "(基因显著性排名)\n")
