plink_prefix_path="/share/org/YZWL/yzwl_pengyan/01.bioproject/07.eQTL-sQTL/01.eQTL/01.diapause/02.SV/diapause.sv"
expression_bed="diapause.final.sort.bed.gz"
prefix1="diapause.sv.cis"
prefix2="diapause.sv.tran"
covariates_file="cor.txt"
python3 -m tensorqtl ${plink_prefix_path} ${expression_bed} ${prefix1} --covariates ${covariates_file} --window 1000000 --fdr 0.05 --mode cis
python3 -m tensorqtl ${plink_prefix_path} ${expression_bed} ${prefix1}  --covariates ${covariates_file} --cis_output ${prefix1}.cis_qtl.txt.gz --window 1000000 --mode cis_independent
python3 -m tensorqtl ${plink_prefix_path} ${expression_bed} ${prefix2} --covariates ${covariates_file} --batch_size 20000 --pval_threshold 9.390288563567558e-06 --maf_threshold 0.05 --mode trans

plink_prefix_path="/share/org/YZWL/yzwl_pengyan/01.bioproject/07.eQTL-sQTL/01.eQTL/03.all/02.SV/all.sv"
expression_bed="final.sort.bed.gz"
prefix1="all.cis"
prefix2="all.tran"
covariates_file="cor.txt"
python3 -m tensorqtl ${plink_prefix_path} ${expression_bed} ${prefix1} --covariates ${covariates_file} --interaction interaction_factor.tsv --window 1000000 --fdr 0.05 --mode cis_nominal
python3 -m tensorqtl ${plink_prefix_path} ${expression_bed} ${prefix2} --covariates ${covariates_file} --interaction interaction_factor.tsv --batch_size 20000 --pval_threshold 9.390288563567558e-06 --maf_threshold 0.05 --mode trans

