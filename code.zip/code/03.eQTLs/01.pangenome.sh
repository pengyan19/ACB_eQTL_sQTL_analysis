## pangenome
/public/software/singularity-ce-3.11.3/bin/singularity exec /public/home/pengyan/biosoft/soft/pan-genome/vg/cactus_v2.8.1.sif cactus-pangenome ./jobstore ./sample.txt --outDir /public/home/maokaikai/data/13.ACB-pangenome-SNP-SV --outName ACB --reference HF --mgCores 10 --mapCores 10 --consCores 10 --vcf --gfa --workDir work --permissiveContigFilter 0

###
