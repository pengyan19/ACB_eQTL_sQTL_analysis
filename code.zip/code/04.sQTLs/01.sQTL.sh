for i in {1..31}
do
(grep '^#' perind.counts.gz.qqnorm_${i} ; grep -v '^#' perind.counts.gz.qqnorm_${i} | sort -V -T ./ -k1,1 -k2,2 -k3,3n) > perind.counts.gz.qqnorm_${i}.sort.bed
bgzip perind.counts.gz.qqnorm_${i}.sort.bed
done
python prepare_phenotype_table.py perind.counts.gz -p 8

plink_prefix_path="/share/org/YZWL/yzwl_pengyan/01.bioproject/07.eQTL-sQTL/02.sQTL/01.diapause/01.SNP/diapause.snp"
expression_bed="diapause.final.sort.bed.gz"
prefix1="diapause.snp.cis"
prefix2="diapause.snp.tran"
covariates_file="cor.txt"
python3 -m tensorqtl ${plink_prefix_path} ${expression_bed} ${prefix1} --covariates ${covariates_file} --window 1000000 --fdr 0.05 --mode cis
python3 -m tensorqtl ${plink_prefix_path} ${expression_bed} ${prefix1}  --covariates ${covariates_file} --cis_output ${prefix1}.cis_qtl.txt.gz --window 1000000 --mode cis_independent
python3 -m tensorqtl ${plink_prefix_path} ${expression_bed} ${prefix2} --covariates ${covariates_file} --batch_size 20000 --pval_threshold 2.438528952532327e-07 --maf_threshold 0.05 --mode trans


