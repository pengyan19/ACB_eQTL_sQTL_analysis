# ============================================================
# TSS 距离分类关键代码（QTL 变异注释核心逻辑）
# ============================================================
# 功能：将 ChIPseeker 注释结果，按与基因 TSS 的距离
#       合并为 5 个大类：Promoter / Exon / Intron /
#                       Distal Intergenic / Other
#
# 分类规则：
#   - Exon   : 注释以 "Exon" 开头
#   - Intron : 注释以 "Intron" 开头
#   - Promoter           : |distanceToTSS| <= 5000
#   - Other              : 5000 < |distanceToTSS| <= 10000
#   - Distal Intergenic  : |distanceToTSS| > 10000
# ============================================================

# ------------------------------------------------------------
# 1. 分类函数（核心）
# ------------------------------------------------------------
get_anno_group <- function(annotation, distanceToTSS) {
  # 优先级 1: Exon
  if (grepl("^Exon", annotation))    return("Exon")
  # 优先级 2: Intron
  if (grepl("^Intron", annotation))  return("Intron")

  # 优先级 3: 按距离 TSS 绝对值判断
  dist <- abs(distanceToTSS)
  if (dist <= 5000)    return("Promoter")
  if (dist <= 10000)   return("Other")
  return("Distal Intergenic")
}

# ------------------------------------------------------------
# 2. 批量应用分类 + 统计（输入为 ChIPseeker 的 anno_list）
# ------------------------------------------------------------
anno_df_list <- list()   # 保存原始数据框（用于密度图）
anno_stat_list <- list() # 保存统计结果（用于饼图）

for (name in names(anno_list)) {
  # 将 ChIPseeker 注释对象转为数据框
  anno_df <- as.data.frame(anno_list[[name]])

  # 应用自定义分类规则（逐行分类）
  anno_df$Group <- mapply(get_anno_group, anno_df$annotation, anno_df$distanceToTSS)

  # 统计各分组数量和百分比
  anno_stat <- as.data.frame(table(anno_df$Group))
  colnames(anno_stat) <- c("Group", "Count")
  anno_stat$Frequency <- anno_stat$Count / sum(anno_stat$Count) * 100

  anno_df_list[[name]] <- anno_df
  anno_stat_list[[name]] <- anno_stat
}

# 查看统计结果
for (name in names(anno_stat_list)) {
  cat("\n---", name, "---\n")
  print(anno_stat_list[[name]])
}

# ------------------------------------------------------------
# 3. 可视化通用设置（5 个大类）
# ------------------------------------------------------------
library(ggplot2)

# 5 个大组的配色
my_colors <- c(
  "Promoter"          = "#FF8C00",   # 深橙色
  "Exon"              = "#3CB371",   # 中绿色
  "Intron"            = "#6A5ACD",   # 深紫色
  "Distal Intergenic" = "#4682B4",   # 钢蓝色
  "Other"             = "#808080"    # 灰色
)

# 大组显示顺序
group_order <- c("Promoter", "Exon", "Intron", "Distal Intergenic", "Other")

# 密度图横轴截断值（100 kb）
density_xlim <- 100000

# ------------------------------------------------------------
# 4. 饼图（各类型占比）
# ------------------------------------------------------------
for (name in names(anno_stat_list)) {
  anno_df <- anno_stat_list[[name]]
  anno_df$Group <- factor(anno_df$Group, levels = group_order)
  anno_df <- anno_df[order(anno_df$Group), ]

  p <- ggplot(anno_df, aes(x = "", y = Frequency, fill = Group)) +
    geom_bar(stat = "identity", width = 1, color = "white") +
    coord_polar("y", start = 0) +
    scale_fill_manual(
      values = my_colors,
      labels = paste0(anno_df$Group, " (", round(anno_df$Frequency, 2), "%)")
    ) +
    theme_void() +
    theme(
      legend.position = "right",
      legend.title = element_blank(),
      legend.text = element_text(size = 10)
    ) +
    labs(fill = NULL)

  pdf_file <- paste0(name, "_annotation_pie.pdf")
  pdf(pdf_file, width = 7, height = 6, onefile = FALSE)
  print(p)
  dev.off()
  cat("已输出饼图:", pdf_file, "\n")
}

# ------------------------------------------------------------
# 5. 密度图（距离 TSS 分布，5kb / 10kb 虚线分隔）
# ------------------------------------------------------------
for (name in names(anno_df_list)) {
  anno_df <- anno_df_list[[name]]

  p <- ggplot(anno_df, aes(x = abs(distanceToTSS))) +
    geom_density(color = "#4682B4", linewidth = 0.8) +
    # 5kb 和 10kb 分界线
    geom_vline(xintercept = 5000, linetype = "dashed", color = "gray50", linewidth = 0.6) +
    geom_vline(xintercept = 10000, linetype = "dashed", color = "gray50", linewidth = 0.6) +
    xlim(0, density_xlim) +
    xlab("Distance to TSS (bp)") +
    ylab("Density") +
    theme_bw() +
    theme(
      panel.grid = element_blank(),
      axis.text = element_text(size = 10),
      axis.title = element_text(size = 12)
    )

  pdf_file <- paste0(name, "_distance_density.pdf")
  pdf(pdf_file, width = 7, height = 5, onefile = FALSE)
  print(p)
  dev.off()
  cat("已输出密度图:", pdf_file, "\n")
}
