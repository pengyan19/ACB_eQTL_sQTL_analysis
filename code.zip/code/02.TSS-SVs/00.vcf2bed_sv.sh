#!/bin/bash
# ============================================================
# SV VCF 转 BED 格式（根据 REF/ALT 长度判断类型）
# 用法: bash vcf2bed_sv.sh input.vcf output.bed
# ============================================================

if [ $# -ne 2 ]; then
    echo "用法: bash vcf2bed_sv.sh <input.vcf> <output.bed>"
    exit 1
fi

input_vcf=$1
output_bed=$2

awk '
BEGIN { FS="\t"; OFS="\t" }
/^#/ { next }  # 跳过注释行
{
    chrom = $1
    pos   = $2
    id    = $3
    ref   = $4
    alt   = $5
    
    # 如果有多个ALT（逗号分隔），只取第一个
    split(alt, alts, ",")
    alt = alts[1]
    
    ref_len = length(ref)
    alt_len = length(alt)
    
    if (alt_len > ref_len) {
        # ========== 插入 (INS) ==========
        # ALT 比 REF 长，多出来的就是插入的序列
        # 插入发生在 POS 和 POS+1 之间
        # 用 1bp 区间表示插入位点
        start = pos - 1
        end   = pos
    }
    else if (alt_len < ref_len) {
        # ========== 删除 (DEL) ==========
        # REF 比 ALT 长，多出来的就是被删掉的序列
        # 删除区域（1-based，包含）：POS+1 到 POS + ref_len - 1
        # 转 bed 0-based 半开区间：
        start = pos
        end   = pos + ref_len - 1
    }
    else {
        # ========== 长度相等（SNP 或其他） ==========
        # 默认为 1bp 位点
        start = pos - 1
        end   = pos
    }
    
    # 输出: chrom  start  en
    d  id
    print chrom, start, end, id
}
' "$input_vcf" > "$output_bed"

# 统计结果
total=$(wc -l < "$output_bed")
echo "转换完成！共 $total 个 SV 位点"
echo "输出文件: $output_bed"
