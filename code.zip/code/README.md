# ACB eQTL and sQTL analyses
Code for eQTL and sQTL analyses of the Asian corn borer (ACB).

## Dependencies
- tensorQTL
- LeafCutter
- python >=3.9
- bcftools, samtools
